﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Practica2019GR602.Models
{
    public class marcas
    {
        [Key]
        public int id_marca { get; set; }
        public string nombre_marca { get; set; }
        public string estados { get; set; }
    }
}
