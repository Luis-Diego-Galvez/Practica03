﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class facultadesController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public facultadesController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de Estados EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            IEnumerable<facultades> facultadesList = from e in _contexto.facultades select e;

            if (facultadesList.Count() > 0)
            {
                return Ok(facultadesList);
            }
            return NotFound();
        }

        /// <param name="buscarnombre"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarnombre}")]
        public IActionResult obtenerFacultad(string buscarNombre)
        {
            IEnumerable<facultades> facultadNombre = from e in _contexto.facultades
                                                       where e.nombre_facultad.Contains(buscarNombre)
                                                       select e;
            if (facultadNombre.Count() > 0)
            {
                return Ok(facultadNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarFacultad([FromBody] facultades facultadNueva)
        {
            try
            {
                IEnumerable<facultades> facultadExist = from e in _contexto.facultades
                                                          where e.nombre_facultad == facultadNueva.nombre_facultad
                                                          select e;
                if (facultadExist.Count() == 0)
                {
                    _contexto.facultades.Add(facultadNueva);
                    _contexto.SaveChanges();
                    return Ok(facultadExist);
                }
                return Ok(facultadExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateFacultad([FromBody] facultades facultadModificar)
        {
            facultades facultadExist = (from e in _contexto.facultades
                                          where e.facultad_id == facultadModificar.facultad_id
                                          select e).FirstOrDefault();
            if (facultadExist is null)
            {
                return NotFound();
            }

            facultadExist.nombre_facultad = facultadModificar.nombre_facultad;

            _contexto.Entry(facultadExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(facultadExist);

        }
    }
}
