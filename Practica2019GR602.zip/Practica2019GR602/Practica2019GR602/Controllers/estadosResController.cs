﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class estadosResController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public estadosResController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de Estados EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            IEnumerable<estados_reserva> estadosEqList = from e in _contexto.estados_Reservas select e;

            if (estadosEqList.Count() > 0)
            {
                return Ok(estadosEqList);
            }
            return NotFound();
        }

        /// <param name="buscarnombre"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarnombre}")]
        public IActionResult obtenerEstadoEquipo(char buscarNombre)
        {
            IEnumerable<estados_reserva> estadoNombre = from e in _contexto.estados_Reservas
                                                       where e.estado.Contains(buscarNombre)
                                                       select e;
            if (estadoNombre.Count() > 0)
            {
                return Ok(estadoNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarEstado([FromBody] estados_reserva estadoNuevo)
        {
            try
            {
                IEnumerable<estados_reserva> estadoExist = from e in _contexto.estados_Reservas
                                                          where e.estado == estadoNuevo.estado
                                                          select e;
                if (estadoExist.Count() == 0)
                {
                    _contexto.estados_Reservas.Add(estadoNuevo);
                    _contexto.SaveChanges();
                    return Ok(estadoExist);
                }
                return Ok(estadoExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateEstado([FromBody] estados_reserva estadoModificar)
        {
            estados_reserva estadoExist = (from e in _contexto.estados_Reservas
                                          where e.estado_res_id == estadoModificar.estado_res_id
                                          select e).FirstOrDefault();
            if (estadoExist is null)
            {
                return NotFound();
            }

            estadoExist.estado = estadoModificar.estado;

            _contexto.Entry(estadoExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(estadoExist);

        }
    }
}
