﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class usuariosController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public usuariosController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            var usuariosList = from e in _contexto.usuarios 
                               join c in _contexto.carreras on e.carrera_id equals c.carrera_id
                               select new 
                               { 
                                    e.usuario_id,
                                    e.nombre,
                                    e.documento,
                                    e.tipo,
                                    e.carnet,
                                    e.carrera_id,
                                    c.nombre_carrera
                               };

            if (usuariosList.Count() > 0)
            {
                return Ok(usuariosList);
            }
            return NotFound();
        }

        /// <param name="buscarcarnet"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarcarnet}")]
        public IActionResult obtenerCarnet(string buscarCarnet)
        {
            IEnumerable<usuarios> usuarioNombre = from e in _contexto.usuarios
                                                where e.carnet.Contains(buscarCarnet)
                                                select e;
            if (usuarioNombre.Count() > 0)
            {
                return Ok(usuarioNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarUser([FromBody] usuarios usuarioNuevo)
        {
            try
            {
                IEnumerable<usuarios> usuarioExist = from e in _contexto.usuarios
                                                   where e.carnet == usuarioNuevo.carnet

                                                   select e;
                if (usuarioExist.Count() == 0)
                {
                    _contexto.usuarios.Add(usuarioNuevo);
                    _contexto.SaveChanges();
                    return Ok(usuarioExist);
                }
                return Ok(usuarioExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateUser([FromBody] usuarios usuarioModificar)
        {
            usuarios usuarioExist = (from e in _contexto.usuarios
                                   where e.usuario_id == usuarioModificar.usuario_id
                                   select e).FirstOrDefault();
            if (usuarioExist is null)
            {
                return NotFound();
            }

            usuarioExist.carnet = usuarioModificar.carnet;
            usuarioExist.documento = usuarioModificar.documento;
            usuarioExist.tipo = usuarioModificar.tipo;
            usuarioExist.carrera_id = usuarioModificar.carrera_id;

            _contexto.Entry(usuarioExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(usuarioExist);

        }
    }
}
