﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;


namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class marcasController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public marcasController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de Estados EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            IEnumerable<marcas> marcasList = from e in _contexto.marcas select e;

            if (marcasList.Count() > 0)
            {
                return Ok(marcasList);
            }
            return NotFound();
        }

        /// <param name="buscarnombre"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarnombre}")]
        public IActionResult obtenerMarca(string buscarNombre)
        {
            IEnumerable<marcas> marcaNombre = from e in _contexto.marcas
                                                     where e.nombre_marca.Contains(buscarNombre)
                                                     select e;
            if (marcaNombre.Count() > 0)
            {
                return Ok(marcaNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarMarca([FromBody] marcas marcaNueva)
        {
            try
            {
                IEnumerable<marcas> marcaExist = from e in _contexto.marcas
                                                        where e.nombre_marca == marcaNueva.nombre_marca
                                                        select e;
                if (marcaExist.Count() == 0)
                {
                    _contexto.marcas.Add(marcaNueva);
                    _contexto.SaveChanges();
                    return Ok(marcaExist);
                }
                return Ok(marcaExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateMarca([FromBody] marcas marcaModificar)
        {
            marcas marcaExist = (from e in _contexto.marcas
                                        where e.id_marca == marcaModificar.id_marca
                                        select e).FirstOrDefault();
            if (marcaExist is null)
            {
                return NotFound();
            }

            marcaExist.nombre_marca = marcaModificar.nombre_marca;

            _contexto.Entry(marcaExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(marcaExist);

        }
    }
}
