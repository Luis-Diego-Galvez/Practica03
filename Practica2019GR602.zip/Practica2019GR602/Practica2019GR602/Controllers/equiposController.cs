﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class equiposController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public equiposController(prestamosContext miContexto) {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get() {
            var equiposList = from e in _contexto.equipos 
                              join te in _contexto.tipo_Equipos on e.tipo_equipo_id equals te.id_tipo_equipo
                              join mm in _contexto.marcas on e.marca_id equals mm.id_marca
                              join ee in _contexto.estados_Equipos on e.estado_equipo_id equals ee.id_estados_equipo
                              select new
                              {
                                  e.id_equipos,
                                  e.nombre,
                                  e.descripcion,
                                  e.tipo_equipo_id,
                                  equipo_tipo_des = te.descripcion,
                                  e.marca_id,
                                  mm.nombre_marca,
                                  e.modelo,
                                  e.anio_compra,
                                  e.costo,
                                  e.vida_util,
                                  e.estado_equipo_id,
                                  estado_equipo_des = ee.descripcion,
                                  e.estado
                              };

            if (equiposList.Count() > 0) {
                return Ok(equiposList);
            }
            return NotFound();
        }

        [HttpGet]
        [Route("api/equipos/{id}")]
        public IActionResult getByID(int id)
        {
            var equiposList = from e in _contexto.equipos
                              join te in _contexto.tipo_Equipos on e.tipo_equipo_id equals te.id_tipo_equipo
                              join mm in _contexto.marcas on e.marca_id equals mm.id_marca
                              join ee in _contexto.estados_Equipos on e.estado_equipo_id equals ee.id_estados_equipo
                              where e.id_equipos == id
                              select new
                              {
                                  e.id_equipos,
                                  e.nombre,
                                  e.descripcion,
                                  e.tipo_equipo_id,
                                  equipo_tipo_des = te.descripcion,
                                  e.marca_id,
                                  mm.nombre_marca,
                                  e.modelo,
                                  e.anio_compra,
                                  e.costo,
                                  e.vida_util,
                                  e.estado_equipo_id,
                                  estado_equipo_des = ee.descripcion,
                                  e.estado
                              };

            if (equiposList.Count() > 0)
            {
                return Ok(equiposList);
            }
            return NotFound();
        }

        [HttpGet]
        [Route("api/equipos/tipo/{idtipo}")]
        public IActionResult getByTipo(int idtipo)
        {
            var equiposList = from e in _contexto.equipos
                              join te in _contexto.tipo_Equipos on e.tipo_equipo_id equals te.id_tipo_equipo
                              join mm in _contexto.marcas on e.marca_id equals mm.id_marca
                              join ee in _contexto.estados_Equipos on e.estado_equipo_id equals ee.id_estados_equipo
                              where te.id_tipo_equipo == idtipo
                              select new
                              {
                                  e.id_equipos,
                                  e.nombre,
                                  e.descripcion,
                                  e.tipo_equipo_id,
                                  equipo_tipo_des = te.descripcion,
                                  e.marca_id,
                                  mm.nombre_marca,
                                  e.modelo,
                                  e.anio_compra,
                                  e.costo,
                                  e.vida_util,
                                  e.estado_equipo_id,
                                  estado_equipo_des = ee.descripcion,
                                  e.estado
                              };

            if (equiposList.Count() > 0)
            {
                return Ok(equiposList);
            }
            return NotFound();
        }

        /// <param name="buscarnombre"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarnombre}")]
        public IActionResult obtenerNombre(string buscarNombre)
        {
            var equipoNombre = from e in _contexto.equipos
                               join te in _contexto.tipo_Equipos on e.tipo_equipo_id equals te.id_tipo_equipo
                               join mm in _contexto.marcas on e.marca_id equals mm.id_marca
                               join ee in _contexto.estados_Equipos on e.estado_equipo_id equals ee.id_estados_equipo
                               where e.nombre.Contains(buscarNombre)
                                  select new
                                  {
                                      e.id_equipos,
                                      e.nombre,
                                      e.descripcion,
                                      e.tipo_equipo_id,
                                      equipo_tipo_des = te.descripcion,
                                      e.marca_id,
                                      mm.nombre_marca,
                                      e.modelo,
                                      e.anio_compra,
                                      e.costo,
                                      e.vida_util,
                                      e.estado_equipo_id,
                                      estado_equipo_des = ee.descripcion,
                                      e.estado
                                  };
            if (equipoNombre.Count() > 0)
            {
                return Ok(equipoNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarEquipo([FromBody] equipos equipoNuevo)
        {
            try
            {
                var equipoExist = from e in _contexto.equipos
                                  join te in _contexto.tipo_Equipos on e.tipo_equipo_id equals te.id_tipo_equipo
                                  join mm in _contexto.marcas on e.marca_id equals mm.id_marca
                                  join ee in _contexto.estados_Equipos on e.estado_equipo_id equals ee.id_estados_equipo
                                  where e.nombre == equipoNuevo.nombre
                                    select new
                                    {
                                        e.id_equipos,
                                        e.nombre,
                                        e.descripcion,
                                        e.tipo_equipo_id,
                                        equipo_tipo_des = te.descripcion,
                                        e.marca_id,
                                        mm.nombre_marca,
                                        e.modelo,
                                        e.anio_compra,
                                        e.costo,
                                        e.vida_util,
                                        e.estado_equipo_id,
                                        estado_equipo_des = ee.descripcion,
                                        e.estado
                                    };
                if (equipoExist.Count() == 0)
                {
                    _contexto.equipos.Add(equipoNuevo);
                    _contexto.SaveChanges();
                    return Ok(equipoExist);
                }
                return Ok(equipoExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateEquipo([FromBody] equipos equipoModificar)
        {
            var equipoExist = (from e in _contexto.equipos
                                   join te in _contexto.tipo_Equipos on e.tipo_equipo_id equals te.id_tipo_equipo
                                   join mm in _contexto.marcas on e.marca_id equals mm.id_marca
                                   join ee in _contexto.estados_Equipos on e.estado_equipo_id equals ee.id_estados_equipo
                                   where e.id_equipos == equipoModificar.id_equipos && te.id_tipo_equipo == equipoModificar.id_equipos &&
                                   e.marca_id == mm.id_marca && e.estado_equipo_id == ee.id_estados_equipo
                                    select new
                                    {
                                        e.id_equipos,
                                        e.nombre,
                                        e.descripcion,
                                        e.tipo_equipo_id,
                                        equipo_tipo_des = te.descripcion,
                                        e.marca_id,
                                        mm.nombre_marca,
                                        e.modelo,
                                        e.anio_compra,
                                        e.costo,
                                        e.vida_util,
                                        e.estado_equipo_id,
                                        estado_equipo_des = ee.descripcion,
                                        e.estado
                                    }).FirstOrDefault();
            if (equipoExist is null)
            {
                return NotFound();
            }

            equipoExist.nombre      = equipoModificar.nombre;
            equipoExist.descripcion = equipoModificar.descripcion;
            equipoExist.modelo      = equipoModificar.modelo;

            _contexto.Entry(equipoExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(equipoExist);

        }
    }
}
