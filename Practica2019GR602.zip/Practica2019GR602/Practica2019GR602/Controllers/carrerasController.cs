﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Practica2019GR602.Models;

namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class carrerasController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public carrerasController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            var carrerasList = from e in _contexto.carreras 
                               join f in _contexto.facultades on e.facultad_id equals f.facultad_id
                               select new {
                                  e.carrera_id,
                                  e.nombre_carrera,
                                  e.facultad_id,
                                  f.nombre_facultad
                               };

            if (carrerasList.Count() > 0)
            {
                return Ok(carrerasList);
            }
            return NotFound();
        }

        [HttpGet]
        [Route("api/equipos/{id}")]
        public IActionResult getByID(int id)
        {
            var carrera = from e in _contexto.carreras
                          join te in _contexto.facultades on e.facultad_id equals te.facultad_id                     
                          select new
                          {
                              e.carrera_id,
                              e.nombre_carrera,
                              e.facultad_id,
                              te.nombre_facultad,
                             
                          };

            if (carrera.Count() > 0)
            {
                return Ok(carrera);
            }
            return NotFound();
        }

        [HttpGet]
        [Route("api/equipos/facultad/{idFacultad}")]
        public IActionResult getByTipo(int idFacultad)
        {
            var carrera = from e in _contexto.carreras
                              join f in _contexto.facultades on e.facultad_id equals f.facultad_id
                              where  f.facultad_id == idFacultad 
                              select new
                              {
                                  e.carrera_id,
                                  e.nombre_carrera,
                                  e.facultad_id,
                                  f.nombre_facultad
                              };

            if (carrera.Count() > 0)
            {
                return Ok(carrera);
            }
            return NotFound();
        }

        /// <param name="buscarnombre"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarnombre}")]
        public IActionResult obtenerNombre(string buscarNombre)
        {
            var carreraNombre = from e in _contexto.carreras
                                join f in _contexto.facultades on e.facultad_id equals f.facultad_id
                                where e.nombre_carrera.Contains(buscarNombre)
                                select new
                                {
                                    e.carrera_id,
                                    e.nombre_carrera,
                                    e.facultad_id,
                                    f.nombre_facultad
                                };
            if (carreraNombre.Count() > 0)
            {
                return Ok(carreraNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarCarrera([FromBody] carreras carreraNueva)
        {
            try
            {
                var carreraExist = from e in _contexto.carreras
                                   join f in _contexto.facultades on e.facultad_id equals f.facultad_id
                                   where e.nombre_carrera == carreraNueva.nombre_carrera
                                   select new
                                   {
                                       e.carrera_id,
                                       e.nombre_carrera,
                                       e.facultad_id,
                                       f.nombre_facultad
                                   };
                if (carreraExist.Count() == 0)
                {
                    _contexto.carreras.Add(carreraNueva);
                    _contexto.SaveChanges();
                    return Ok(carreraExist);
                }
                return Ok(carreraExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateCarrera([FromBody] carreras carreraModificar)
        {
            var carreraExist = (from e in _contexto.carreras
                                join f in _contexto.facultades on e.facultad_id equals f.facultad_id
                                where e.carrera_id == carreraModificar.carrera_id
                                select new
                                {
                                    e.carrera_id,
                                    e.nombre_carrera,
                                    e.facultad_id,
                                    f.nombre_facultad
                                }).FirstOrDefault();
            if (carreraExist is null)
            {
                return NotFound();
            }

            carreras cc = new carreras();
            cc.carrera_id = carreraModificar.carrera_id;
            cc.nombre_carrera = carreraModificar.nombre_carrera;
            cc.facultad_id = carreraModificar.facultad_id;



            _contexto.Entry(cc).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(carreraExist);

        }
    }
}
}
