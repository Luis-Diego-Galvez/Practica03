﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica2019GR602.Properties
{
    [Route("api/[controller]")]
    [ApiController]
    public class estadosEquiposController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public estadosEquiposController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de Estados EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            IEnumerable<estados_equipo> estadosEqList = from e in _contexto.estados_Equipos select e;

            if (estadosEqList.Count() > 0)
            {
                return Ok(estadosEqList);
            }
            return NotFound();
        }

        /// <param name="buscarnombre"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarnombre}")]
        public IActionResult obtenerEstadoEquipo(char buscarNombre)
        {
            IEnumerable<estados_equipo> estadoNombre = from e in _contexto.estados_Equipos
                                                       where e.estado == buscarNombre
                                                       select e;
            if (estadoNombre.Count() > 0)
            {
                return Ok(estadoNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarEstado([FromBody] estados_equipo estadoNuevo)
        {
            try
            {
                IEnumerable<estados_equipo> estadoExist = from e in _contexto.estados_Equipos
                                                   where e.descripcion == estadoNuevo.descripcion
                                                   select e;
                if (estadoExist.Count() == 0)
                {
                    _contexto.estados_Equipos.Add(estadoNuevo);
                    _contexto.SaveChanges();
                    return Ok(estadoExist);
                }
                return Ok(estadoExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateEstado([FromBody] estados_equipo estadoModificar)
        {
            estados_equipo estadoExist = (from e in _contexto.estados_Equipos
                                   where e.id_estados_equipo == estadoModificar.id_estados_equipo
                                   select e).FirstOrDefault();
            if (estadoExist is null)
            {
                return NotFound();
            }

            estadoExist.descripcion = estadoModificar.descripcion;
            estadoExist.estado = estadoModificar.estado;

            _contexto.Entry(estadoExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(estadoExist);

        }
    }
}
