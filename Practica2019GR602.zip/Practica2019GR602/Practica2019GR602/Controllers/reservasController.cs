﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class reservasController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public reservasController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            var reservasList = from e in _contexto.reservas select e;

            if (reservasList.Count() > 0)
            {
                return Ok(reservasList);
            }
            return NotFound();
        }

        /// <param name="buscarequipo"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscarequipo}")]
        public IActionResult obtenerEquipo(int buscarEquipo)
        {
            IEnumerable<reservas> reservaNombre = from e in _contexto.reservas
                                                  where e.equipo_id == buscarEquipo
                                                  select e;
            if (reservaNombre.Count() > 0)
            {
                return Ok(reservaNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarReserva([FromBody] reservas reservaNueva)
        {
            try
            {
                IEnumerable<reservas> reservaExist = from e in _contexto.reservas
                                                     where e.reserva_id == reservaNueva.reserva_id

                                                     select e;
                if (reservaExist.Count() == 0)
                {
                    _contexto.reservas.Add(reservaNueva);
                    _contexto.SaveChanges();
                    return Ok(reservaExist);
                }
                return Ok(reservaExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateReserva([FromBody] reservas reservaModificar)
        {
            reservas reservaExist = (from e in _contexto.reservas
                                     where e.reserva_id == reservaModificar.reserva_id
                                     select e).FirstOrDefault();
            if (reservaExist is null)
            {
                return NotFound();
            }

            reservaExist.equipo_id = reservaModificar.equipo_id;
            reservaExist.estado_reserva_id = reservaModificar.estado_reserva_id;
            reservaExist.fecha_retorno = reservaModificar.fecha_retorno;
            reservaExist.fecha_salida = reservaModificar.fecha_salida;
            reservaExist.hora_retorno = reservaModificar.hora_retorno;
            reservaExist.hora_salida = reservaModificar.hora_salida;
            reservaExist.tiempo_reserva = reservaModificar.tiempo_reserva;
            reservaExist.usuario_id = reservaModificar.usuario_id;

            _contexto.Entry(reservaExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(reservaExist);

        }
    }
}
