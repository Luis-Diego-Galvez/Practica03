﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practica2019GR602.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica2019GR602.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tipoEquipoController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public tipoEquipoController(prestamosContext miContexto)
        {
            this._contexto = miContexto;
        }

        /// <summary>
        /// Metodo de Retorno de los Reg. de EQUIPOS
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            IEnumerable<usuarios> tiposList = from e in _contexto.usuarios select e;

            if (tiposList.Count() > 0)
            {
                return Ok(tiposList);
            }
            return NotFound();
        }

        /// <param name="buscartipo"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipos/buscarnombre/{buscartipo}")]
        public IActionResult obtenerTipo(string buscarTipo)
        {
            IEnumerable<tipo_equipo> tipoNombre = from e in _contexto.tipo_Equipos
                                                  where e.descripcion.Contains(buscarTipo)
                                                  select e;
            if (tipoNombre.Count() > 0)
            {
                return Ok(tipoNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarTipo([FromBody] usuarios tipoNuevo)
        {
            try
            {
                IEnumerable<usuarios> tipoExist = from e in _contexto.usuarios
                                                     where e.carnet == tipoNuevo.carnet

                                                     select e;
                if (tipoExist.Count() == 0)
                {
                    _contexto.usuarios.Add(tipoNuevo);
                    _contexto.SaveChanges();
                    return Ok(tipoExist);
                }
                return Ok(tipoExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateTipo([FromBody] tipo_equipo tipoModificar)
        {
            tipo_equipo tipoExist = (from e in _contexto.tipo_Equipos
                                     where e.id_tipo_equipo == tipoModificar.id_tipo_equipo
                                     select e).FirstOrDefault();
            if (tipoExist is null)
            {
                return NotFound();
            }

            tipoExist.descripcion = tipoModificar.descripcion;
            tipoExist.estado = tipoModificar.estado;

            _contexto.Entry(tipoExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(tipoExist);

        }
    }
}
